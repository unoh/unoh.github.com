#!/bin/sh
touch AUTHORS ChangeLog NEWS README
test -e config || mkdir config
aclocal
libtoolize
aclocal
autoheader
automake -af
autoconf
