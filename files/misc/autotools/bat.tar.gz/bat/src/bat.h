#ifndef CAT_H
#define CAT_H

extern int bat  __P((FILE *, FILE *));

#endif /* ifndef CAT_H */
