#ifndef INCLUDES_H
#define INCLUDES_H

#if HAVE_CONFIG_H
#  include "config.h"
#endif

#include <stdio.h>

#ifndef __P
#  if __STDC__
#    define __P(x) x
#  else
#    define __P(x) ()
#  endif
#endif

#include "bat.h"

#endif /* ifndef INCLUDES_H */
