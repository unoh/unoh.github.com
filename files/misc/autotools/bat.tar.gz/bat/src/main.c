/* vim: set expandtab tabstop=4 shiftwidth=4: */
#if HAVE_CONFIG_H
#  include "config.h"
#endif

#include "includes.h"

int
main()
{
    return bat(stdin, stdout);
}
