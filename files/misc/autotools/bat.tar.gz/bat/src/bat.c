/* vim: set expandtab tabstop=4 shiftwidth=4: */
#if HAVE_CONFIG_H
#  include "config.h"
#endif

#include "includes.h"

int
bat(instream, outstream)
    FILE *instream;
    FILE *outstream;
{
    int c;

    while (c = getc(instream)) {
        putc(c, outstream);
    }

    return 0;
}
