#ifndef TESTAPP_H_
#define TESTAPP_H_


class TestApp: public wxApp {
public:
    bool OnInit();
};

#endif /*TESTAPP_H_*/
