#include <wx/wx.h>

#include "TestApp.h"
#include "TestFrame.h"

IMPLEMENT_APP(TestApp)

bool TestApp::OnInit()
{
    wxInitAllImageHandlers();
    TestFrame* p_mYskFrame = new TestFrame(NULL, wxID_ANY, wxT("test editor"));
    SetTopWindow(p_mYskFrame);
    p_mYskFrame->Show();
    return true;
}



