<?php
declare(ticks=1);
mb_internal_encoding('UTF-8');
require_once 'Services/Lingr.php';

class Lingr_Bot
{
    var $api_key;
    
    var $session_id;

    // fix me multi username && room
    var $room_id = '';
    var $username = '';
    var $counter = '';
    
    var $pid = '';
    
    var $active = false;
    var $lingr;

    function Lingr_Bot()
    {
        $this->lingr = new Services_Lingr($this->api_key);
        $this->active = false;
    }

    function perform()
    {
        $this->_fork();
        
        
        $this->session_id = $this->lingr->session->create();
        $this->active = true;
        
        $options = array('nickname' => $this->username);
        $enter = $this->lingr->room->enter($this->session_id, $this->room_id, $options);
        $this->counter = $enter['room']['counter'];
        while (1) {
            $data = $this->lingr->room->observe($this->counter);
            if(! isset($data['counter'])){
                usleep(10000);
                continue;
            }
            $this->counter = $data['counter'];
            if (isset($data['messages']) && is_array($data['messages'])) {
                $this->getMessages($data);
            }
        }
    }

    function _fork()
    {
        $this->pid = pcntl_fork();
        if ($this->pid == -1) {
             die("fork is failed"); 
        } else if ($this->pid) {
             exit();
        }
        pcntl_signal(SIGTERM, array(&$this, 'signal'));
        pcntl_signal(SIGHUP, array(&$this, 'signal'));
    }

    function getMessages($data)
    {
        foreach ($data['messages'] as $key => $value) {
            $this->getMessage($value);
        }
    }

    function getMessage($message)
    {
    
    }

    function signal($signo)
    {
        switch ($signo) {
            case SIGTERM:
                if ($this->active) {
                    $this->lingr->room->leave();
                    $this->lingr->session->destroy($this->session_id);
                }
                exit;
                break;
            case SIGHUP:
                //fix me
                break;
            default:    
        }
    }

}

