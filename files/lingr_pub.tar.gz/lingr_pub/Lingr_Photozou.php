<?php
require ('Lingr_Bot.php');
require ('Services/Photozou.php');

function make_seed()
{
    list($usec, $sec) = explode(' ', microtime());
    return (float) $sec + ((float) $usec * 100000);
}

mt_srand(make_seed());


class Lingr_Photozou extends Lingr_Bot
{
    var $photozou_username = '';
    var $photozou_password = '';
    var $search_params = array(
                        'type' => 'photo',
//                        'copyright' => 'creativecommons',
                        );

    function Lingr_Photozou()
    {
        parent::Lingr_Bot();
        $this->photozou = new Services_Photozou($this->photozou_username, $this->photozou_password);
    }
    function getMessage($message)
    {    
        if (! isset($message['text'])) {
            return 0;
        }

        if (! isset($message['client_type']) || $message['client_type'] !== 'human') {
            return 0;
        }

        //preg_match('/(フォト蔵|photozou)>>[ 　]*([^ 　]*)/iu';
        if (mb_eregi('photozou>>[ 　]*([^ 　]*)', $message['text'], $matches)
            || mb_eregi('フォト蔵>>[ 　]*([^ 　]*)', $message['text'], $matches)) {
            $image_url = $this->getPhotozouPublicRandam($matches[1]);
            if ($image_url !== false) {
                $say = $image_url;
            } else {
                $say = 'no match files';
            }
            $this->lingr->room->say($say);
        }
    }
    
    function getPhotozouPublicRandam($keyword)
    {
        $params = $this->search_params;
        $params['limit'] = 1;
        $params['offset'] = mt_rand(0, 999);
        $params['keyword'] = $keyword;
        
        $data = $this->photozou->search_public($params);
        if (count($data) >= 1) {
            return sprintf("%s %s", $data[0]['image_url'], $data[0]['url']);
        }
        return false;
    }
}

