<?php
declare(ticks=1);
require ('Lingr_Photozou.php');
class MyLingr_Photozou extends Lingr_Photozou
{
    var $api_key = '__lingr_api_key__';
    var $room_id = '__lingr_room_id__';
    var $username = '___login_user_name__';
}

$MyLingr_Photozou = new MyLingr_Photozou();
$MyLingr_Photozou->perform();
