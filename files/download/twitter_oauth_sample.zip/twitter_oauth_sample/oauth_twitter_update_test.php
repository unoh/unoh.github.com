<?php
include_once('oauth_twitter_common.php');

$token = @$_GET['token'];
$token_secret = @$_GET['token_secret'];
$q = get_parameters($token);

// Test update
$header = array();

$text = urlencode(microtime());

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "http://twitter.com/statuses/update.xml?status={$text}&{$q}");
curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$response = curl_exec($ch);
if (!$response) {
    die("Failed request token");
}
curl_close($ch);

$xml = simplexml_load_string($response);
?>

<h1>OAuth - twitter - Update test</h1>

<p><a href="http://twitter.com/n0ts/statuses/<?php echo $xml->id ?>" target="_blank">Status permalink</a></p>
<ul>
  <li>Access token: <?php echo $token ?></li>
  <li>Token secret: <?php echo $token_secret ?></li>
  <li><a href="oauth_twitter_update_test.php?token=<?php echo $token ?>&token_secret=<?php echo $token_secret ?>">Update test again!</a></li>
</ul>
