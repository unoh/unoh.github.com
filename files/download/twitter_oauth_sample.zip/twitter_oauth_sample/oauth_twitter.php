<html>
<body>
<h1>OAuth - twitter</h1>
<p><a href="oauth_twitter_request.php">Request Token</a></p>
</body>
</html>
