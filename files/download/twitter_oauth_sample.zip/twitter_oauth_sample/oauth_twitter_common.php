<?php
function get_parameters($token = '', $is_header = false, $secret = '')
{
    $key = 'Consumer Key';
    $secret = ($secret) ? $secret : 'Cosumer Secret';
    $parameters = array('oauth_consumer_key' => $key,
                        'oauth_signature_method' => 'PLAINTEXT',
                        'oauth_signature' => $secret,
                        'oauth_timestamp' => time(),
                        'oauth_nonce' => md5(microtime() . mt_rand()),
                        'oauth_version' => '1.0'
                        );
    if ($token) {
       $parameters['oauth_token'] = $token;
    }

    $q = array();
    foreach ($parameters as $k => $v) {
        if ($is_header) {
            $q []= urlencode($k) . '=' . '"' . urlencode($v) . '"';
        } else {
            $q []= urlencode($k) . '=' . urlencode($v);
        }
    }
    if ($is_header) {
        $q = implode(',', $q);
    } else {
        $q = implode('&', $q);
    }
    return $q;
}
