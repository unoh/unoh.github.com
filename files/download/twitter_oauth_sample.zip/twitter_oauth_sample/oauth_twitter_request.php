<?php
include_once('oauth_twitter_common.php');

$q = get_parameters();

// Request token
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "http://twitter.com/oauth/request_token?{$q}");
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$response = curl_exec($ch);
if (!$response) {
    die("Failed request token");
}
curl_close($ch);

$response = split("&", $response);
$oauth_tokens = array();
foreach ($response as $res) {
    list($key, $val) = split("=", $res);
    $oauth_tokens[$key] = $val;
}

header("Location: http://twitter.com/oauth/authorize?{$q}&oauth_token={$oauth_tokens['oauth_token']}");
