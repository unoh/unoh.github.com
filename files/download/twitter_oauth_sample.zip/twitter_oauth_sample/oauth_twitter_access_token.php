<?php
include_once('oauth_twitter_common.php');

$token = @$_GET['token'];
$q = get_parameters($token);

// Request token
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "http://twitter.com/oauth/access_token?{$q}");
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$response = curl_exec($ch);
if (!$response) {
    die("Failed request token");
}
curl_close($ch);

$response = split("&", $response);
$oauth_tokens = array();
foreach ($response as $res) {
    list($key, $val) = split("=", $res);
    $oauth_tokens[$key] = $val;
}
?>

<h1>OAuth - twitter - Access token</h1>
<ul>
  <li>oauth_token: <?php echo $oauth_tokens['oauth_token'] ?></li>
  <li>oauth_token_secret: <?php echo $oauth_tokens['oauth_token_secret'] ?></li>
  <li><a href="oauth_twitter_update_test.php?token=<?php echo $oauth_tokens['oauth_token'] ?>&token_secret=<?php echo $oauth_tokens['oauth_token_secret'] ?>">Update test</a></li>
</ul>
