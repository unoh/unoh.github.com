<?php
include_once('oauth_twitter_common.php');

$token = @$_GET['token'];
?>

<html>
<body>
<h1>OAuth - twitter - Callback</h1>
<p><a href="oauth_twitter_access_token.php?token=<?php echo $token ?>">Get Access Token</a></p>
</ol>
</body>
</html>
