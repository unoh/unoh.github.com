/**
 * ---------------------------------------------------------------------
 * ImageFlow JavaScript for clipp
 * ---------------------------------------------------------------------
 * A slight modified version of Finn Rudolph's
 * ImageFlow JavaScript <http://imageflow.finnrudolph.de/>
 * which is based on Michael L. Perry's
 * Cover flow in Javascript <http://myscraproom.net/>
 * for exclusive use in clipp <http://clipp.in/>
 *
 * @author      Finn Rudolph <http://www.finnrudolph.de/>
 * @author      ISOGAWA, Tadasu, Unoh Inc. <isogawa@unoh.net>
 * @require     jQuery 1.2.x <http://jquery.com/>
 * @see         http://imageflow.finnrudolph.de/
 * @see         http://clipp.in/
 *
 * Please note that most comments in this source are as is in the original
 * version and are not updated according to changes made here.
 * So some could be inappropriate for the actual content.
 * The comment in the original header is as follow:
 * ---------------------------------------------------------------------
 * ImageFlow 0.9
 *
 * This code is based on Michael L. Perrys Cover flow in Javascript.
 * For he wrote that "You can take this code and use it as your own" [1]
 * this is my attempt to improve some things. Feel free to use it! If
 * you have any questions on it leave me a message in my shoutbox [2].
 *
 * The reflection is generated server-sided by a slightly hacked
 * version of Richard Daveys easyreflections [3] written in PHP.
 *
 * The mouse wheel support is an implementation of Adomas Paltanavicius
 * JavaScript mouse wheel code [4].
 *
 * Thanks to Stephan Droste ImageFlow is now compatible with Safari 1.x.
 *
 *
 * [1] http://www.adventuresinsoftware.com/blog/?p=104#comment-1981
 * [2] http://shoutbox.finnrudolph.de/
 * [3] http://reflection.corephp.co.uk/v2.php
 * [4] http://adomas.org/javascript-mouse-wheel/
 */

var ImageFlow = {
    /* Configuration variables */
    conf: {
        reflectionPercent: 0.5, // Sets the height of the reflection in % of the source image
        focus: 4,               // Sets the numbers of images on each side of the focussed one
        sliderWidth: 14         // Sets the px width of the slider div
    },
    /* Define global variables */
    arrayImages: [],
    dragObject: null,
    dragging: false,
    xStep: 150,
    captionId: 0,
    current: 0,
    target: 0,
    memTarget: 0,
    timer: 0,
    newSliderPos: 0,
    dragX: 0,
    posX: 0,
    newPosX: 0,
    imagesWidth: 0,
    imagesTop: 0,
    imagesLeft: 0,
    maxFocus: 0,
    size: 0,
    scrollbarWidth: 0,
    sliderWidth: 0,
    maxHeight: 0,
    loadedImages: 0,

    load: function(username) {
        $(document).keydown(function(e) {
            if (e == null) {
                keycode = event.keyCode;
            } else {
                keycode = e.which;
            }
            if (keycode == 27) {
                ImageFlow.dismiss();
            }
        });
        $('#loading').show();
        $.ajax({
            type: 'GET',
            url: '/imageflow.php',
            data: {username: username},
            timeout: 10000,
            success: function(response) {
                if (!document.getElementById('imageflow-container')) {
                    var divElement = document.createElement('div');
                    document.body.appendChild(divElement);
                    divElement.setAttribute('id', 'imageflow-container');
                }
                ImageFlow.loadedImages = 0;
                $('#imageflow-container').html(response);
                var imgs = $('#imageflow-images img');
                if (imgs.length <= 0) {
                    ImageFlow.dismiss();
                } else {
                    $(imgs).each(function() {
                        $(this).load(function() {
                            ImageFlow.loadedImages++;
                            if (ImageFlow.loadedImages >= imgs.length) {
                                ImageFlow.init();
                            }
                        });
                    });
                }
            },
            error: function(response) {
                if (response.responseText) {
                    alert(response.responseText);
                }
                ImageFlow.dismiss();
            }
        });
    },

    init: function() {
        $('#loading').hide();
        $('#imageflow-mask').show();
        if (this.dragX != 0) {
            this.captionId = 0;
            this.current = 0;
            this.target = 0;
            this.memTarget = 0;
            this.timer = 0;
            this.newSliderPos = 0;
            this.dragX = 0;
            this.posX = 0;
            this.newPosX = 0;
        }
        this.refresh(true);
        this.initMouseWheel();
        this.initMouseDrag();
        $('#imageflow-images').css('visibility', 'visible');
        $('#imageflow-controls').css('visibility', 'visible');
        $('#imageflow-scrollbar').css('visibility', 'visible');
        $(window)
            /* Refresh ImageFlow on window resize */
            .resize(function() {
                ImageFlow.refresh();
            })
            /* Fixes the back button issue */
            .unload(function() {
                document = null;
            });
        $(document).keydown(function(e) {
            if (e == null) {
                keycode = event.keyCode;
            } else {
                keycode = e.which;
            }
            switch (keycode) {
            case 27:
                ImageFlow.dismiss();
                break;
            /* Left arrow key */
            case 37:
                ImageFlow.handle(1);
                break;
            /* Right arrow key */
            case 39:
                ImageFlow.handle(-1);
                break;
            }
        });
    },

    dismiss: function() {
        $('#loading').hide();
        $('#imageflow').hide();
        $('#imageflow-mask').hide();
        $('#imageflow-container').remove();
        $(document)
            .unbind('keydown')
            .unbind('mousemove')
            .unbind('mouseup')
            .unbind('selectstart');
        $(window)
            .unbind('resize')
            .unbind('unload');
    },

    /* Main function */
    refresh: function(isOnLoad) {
        /* Cache document objects in global variables */
        var imageflowElement = document.getElementById('imageflow');
        var imagesElement = document.getElementById('imageflow-images');
        /* Cache global variables, that only change on refresh */
        this.imagesWidth = imagesElement.offsetWidth;
        this.imagesTop = imageflowElement.offsetTop;
        this.imagesLeft = imageflowElement.offsetLeft;
        this.maxFocus = this.conf.focus * this.xStep;
        this.size = this.imagesWidth *0.5;
        this.scrollbarWidth = this.imagesWidth *0.6;
        this.sliderWidth = this.conf.sliderWidth *0.5;
        this.maxHeight = this.imagesWidth *0.51;
        /* Change imageflow div properties */
        $(imageflowElement).css('height', this.maxHeight + 'px');
        /* Change images div properties */
        $(imagesElement).css('height', this.imagesWidth *0.338 + 'px');
        /* Change captions div properties */
        $('#imageflow-captions')
            .css('width', this.imagesWidth + 'px')
            .css('marginTop', this.imagesWidth *0.03 + 'px');
        /* Change scrollbar div properties */
        $('#imageflow-scrollbar')
            .css('marginTop', this.imagesWidth *0.02 + 'px')
            .css('marginLeft', this.imagesWidth *0.2 + 'px')
            .css('width', this.scrollbarWidth + 'px');
        /* Set slider attributes */
        $('#imageflow-slider')
            .css('cursor', 'pointer')
            .mousedown(function() {
                ImageFlow.dragStart(this);
            });
        /* Cache EVERYTHING! */
        this.arrayImages = $('img', $(imagesElement));
        for (var i = 0; i < this.arrayImages.length; i++) {
            var $img = $(this.arrayImages[i]);
            this.arrayImages[i].url = $img.attr('longdesc');
            this.arrayImages[i].posX = (- i * this.xStep);
            this.arrayImages[i].i = i;
            /* Add width and height as attributes ONLY once onload */
            if (isOnLoad == true) {
                this.arrayImages[i].w = this.arrayImages[i].width;
                this.arrayImages[i].h = this.arrayImages[i].height;
            }
            /* Check source image format. Get image height minus reflection height! */
            if ((this.arrayImages[i].w +1) > (this.arrayImages[i].h / (this.conf.reflectionPercent +1))) {
                /* Landscape format */
                this.arrayImages[i].pc = 118;
            } else {
                /* Portrait and square format */
                this.arrayImages[i].pc = 100;
            }
            $img
                /* Set image cursor type */
                .css('cursor', 'pointer')
                /* Set image onclick by adding i and posX as attributes! */
                .click(function() {
                    ImageFlow.glideTo(this.posX, this.i);
                })
                /* Set ondblclick event */
                .dblclick(function() {
                    document.location = this.url;
                });
        }
        /* Display images in current order */
        this.moveTo(this.current);
        this.glideTo(this.current, this.captionId);
    },

    step: function() {
        if (ImageFlow.target < ImageFlow.current -1 || ImageFlow.target > ImageFlow.current +1) {
            ImageFlow.moveTo(ImageFlow.current + (ImageFlow.target - ImageFlow.current) /3);
            window.setTimeout(ImageFlow.step, 50);
            ImageFlow.timer = 1;
        } else {
            ImageFlow.timer = 0;
        }
    },

    glideTo: function(x, newCaptionId) {
        /* Animate gliding to new x position */
        ImageFlow.target = x;
        ImageFlow.memTarget = x;
        if (ImageFlow.timer == 0) {
            window.setTimeout(ImageFlow.step, 50);
            ImageFlow.timer = 1;
        }
        /* Display new caption */
        ImageFlow.captionId = newCaptionId;
        var caption = $(ImageFlow.arrayImages[ImageFlow.captionId]).attr('alt');
        if (caption == '') {
            caption = '&nbsp;';
        }
        $('#imageflow-captions').html(caption);
        /* Set scrollbar slider to new position */
        if (ImageFlow.dragging == false) {
            ImageFlow.newSliderPos = (ImageFlow.scrollbarWidth * (-(x *100 / ((ImageFlow.arrayImages.length - 1) * ImageFlow.xStep))) /100) - ImageFlow.newPosX;
            $('#imageflow-slider').css('marginLeft', (ImageFlow.newSliderPos - ImageFlow.sliderWidth) + 'px');
        }
    },

    moveTo: function(x) {
        ImageFlow.current = x;
        var zIndex = ImageFlow.arrayImages.length;
        /* Main loop */
        for (var i = 0; i < ImageFlow.arrayImages.length; i++) {
            var image = ImageFlow.arrayImages[i];
            var currentImage = i * - ImageFlow.xStep;
            /* Don't display images that are not conf_focussed */
            if ((currentImage + ImageFlow.maxFocus) < ImageFlow.memTarget
                || (currentImage - ImageFlow.maxFocus) > ImageFlow.memTarget) {
                image.style.visibility = 'hidden';
                image.style.display = 'none';
            } else {
                var z = Math.sqrt(10000 + x * x) +100;
                var xs = x / z * ImageFlow.size + ImageFlow.size;
                /* Still hide images until they are processed, but set display style to block */
                image.style.display = 'block';
                /* Process new image height and image width */
                var newImgHeight = (image.h / image.w * image.pc) / z * ImageFlow.size;
                if (newImgHeight > ImageFlow.maxHeight) {
                    newImgHeight = ImageFlow.maxHeight;
                    var newImgWidth = image.w * newImgHeight / image.h;
                } else {
                    var newImgWidth = image.pc / z * ImageFlow.size;
                }
                var newImgTop = (ImageFlow.imagesWidth *0.34 - newImgHeight)
                    + ImageFlow.imagesTop
                    + ((newImgHeight / (ImageFlow.conf.reflectionPercent +1)) * ImageFlow.conf.reflectionPercent);
                /* Set new image properties */
                image.style.left = xs - (image.pc /2) / z * ImageFlow.size + ImageFlow.imagesLeft + 'px';
                if (newImgWidth && newImgHeight) {
                    image.style.height = newImgHeight + 'px';
                    image.style.width = newImgWidth + 'px';
                    image.style.top = newImgTop + 'px';
                }
                image.style.visibility = 'visible';
                /* Set image layer through zIndex */
                if (x < 0) {
                    zIndex++;
                } else {
                    zIndex = zIndex -1;
                }
                /* Change zIndex and onclick function of the focussed image */
                if (image.i == ImageFlow.captionId) {
                    zIndex = zIndex +1;
                    image.onclick = function() {
                        document.location = this.url;
                    };
                } else {
                    image.onclick = function() {
                        ImageFlow.glideTo(this.posX, this.i);
                    };
                }
                image.style.zIndex = zIndex;
            }
            x += ImageFlow.xStep;
        }
    },

    /* Handle the wheel angle change (delta) of the mouse wheel */
    handle: function(delta) {
        var changed = false;
        var newCaptionId;
        if (delta > 0) {
            if (this.captionId >= 1) {
                this.target = this.target + this.xStep;
                newCaptionId = this.captionId -1;
                changed = true;
            }
        } else {
            if (this.captionId < (this.arrayImages.length -1)) {
                this.target = this.target - this.xStep;
                newCaptionId = this.captionId +1;
                changed = true;
            }
        }
        /* Glide to next (mouse wheel down) / previous (mouse wheel up) image */
        if (changed == true) {
            this.glideTo(this.target, newCaptionId);
        }
    },

    /* Event handler for mouse wheel event */
    wheel: function(event) {
        var delta = 0;
        if (!event) {
            event = window.event;
        }
        if (event.wheelDelta) {
            delta = event.wheelDelta /120;
        } else if (event.detail) {
            delta = - event.detail /3;
        }
        if (delta) {
            ImageFlow.handle(delta);
        }
        if (event.preventDefault) {
            event.preventDefault();
        }
        event.returnValue = false;
    },

    /* Initialize mouse wheel event listener */
    initMouseWheel: function() {
        var imageflowElement = document.getElementById('imageflow');
        if (window.addEventListener) {
            imageflowElement.addEventListener('DOMMouseScroll', this.wheel, false);
        }
        $(imageflowElement).bind('mousewheel', this.wheel);
    },

    /* This function is called to drag an object (= slider div) */
    dragStart: function(element) {
        this.dragObject = element;
        this.dragX = this.posX - this.dragObject.offsetLeft + this.newSliderPos;
    },

    /* This function is called to stop dragging an object */
    dragStop: function() {
        ImageFlow.dragObject = null;
        ImageFlow.dragging = false;
    },

    /* This function is called on mouse movement and moves an object (= slider div) on user action */
    drag: function(e) {
        ImageFlow.posX = document.all? window.event.clientX: e.pageX;
        if (ImageFlow.dragObject != null) {
            ImageFlow.dragging = true;
            ImageFlow.newPosX = (ImageFlow.posX - ImageFlow.dragX) + ImageFlow.sliderWidth;
            /* Make sure, that the slider is moved in proper relation to previous movements by the glideTo function */
            if (ImageFlow.newPosX < ( - ImageFlow.newSliderPos)) {
                ImageFlow.newPosX = - ImageFlow.newSliderPos;
            }
            if (ImageFlow.newPosX > (ImageFlow.scrollbarWidth - ImageFlow.newSliderPos)) {
                ImageFlow.newPosX = ImageFlow.scrollbarWidth - ImageFlow.newSliderPos;
            }
            var sliderPos = (ImageFlow.newPosX + ImageFlow.newSliderPos);
            var stepWidth = sliderPos / ((ImageFlow.scrollbarWidth) / (ImageFlow.arrayImages.length -1));
            var imageNumber = Math.round(stepWidth);
            var newTarget = (imageNumber) * - ImageFlow.xStep;
            var newCaptionId = imageNumber;
            $(ImageFlow.dragObject).css('left', ImageFlow.newPosX + 'px');
            ImageFlow.glideTo(newTarget, newCaptionId);
        }
    },

    /* Initialize mouse event listener */
    initMouseDrag: function() {
        $(document)
            .mousemove(this.drag)
            .mouseup(this.dragStop)
            /* Avoid text and image selection while dragging  */
            .bind('selectstart', function() {
                return ImageFlow.dragging != true;
            });
    }
}
