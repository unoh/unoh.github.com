from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
_magic_number = 2
_modified_time = 1184735637.921
_template_filename='Z:\\docs\\labs\\cocowiki\\cocowiki\\templates/edit.mak'
_template_uri='/edit.mak'
_template_cache=cache.Cache(__name__, _modified_time)
_source_encoding=None
_exports = ['title']


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, u'base.mak', _template_uri)
def render_body(context,**pageargs):
    context.caller_stack.push_frame()
    try:
        __M_locals = dict(pageargs=pageargs)
        h = context.get('h', UNDEFINED)
        self = context.get('self', UNDEFINED)
        c = context.get('c', UNDEFINED)
        _ = context.get('_', UNDEFINED)
        # SOURCE LINE 1
        context.write(u'\n')
        # SOURCE LINE 2
        context.write(u'\n\n<h2>')
        # SOURCE LINE 4
        context.write(unicode(self.title()))
        context.write(u'</h2>\n')
        # SOURCE LINE 5
        context.write(unicode(h.form(h.url_for(action='update', word=c.word), method='post')))
        context.write(u'\n<p><label>')
        # SOURCE LINE 6
        context.write(unicode( _('Content') ))
        context.write(u'</label><br />\n')
        # SOURCE LINE 7
        context.write(unicode( h.text_area('content', c.form_result['content'], size='60x10') ))
        context.write(u'\n</p>\n<p>\n')
        # SOURCE LINE 10
        context.write(unicode( h.submit(value=_('Update')) ))
        context.write(u'\n</p>\n<p>\n<span>&raquo; ')
        # SOURCE LINE 13
        context.write(unicode( h.link_to(_('Back'), '/%s' % c.word) ))
        context.write(u'</span>\n</p>\n')
        # SOURCE LINE 15
        context.write(unicode( h.end_form() ))
        return ''
    finally:
        context.caller_stack.pop_frame()


def render_title(context):
    context.caller_stack.push_frame()
    try:
        c = context.get('c', UNDEFINED)
        _ = context.get('_', UNDEFINED)
        # SOURCE LINE 2
        context.write(filters.html_escape(unicode( _('Edit the Page "%s"') % c.word )))
        return ''
    finally:
        context.caller_stack.pop_frame()


