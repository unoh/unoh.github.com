from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
_magic_number = 2
_modified_time = 1184725702.9530001
_template_filename=u'Z:\\docs\\labs\\cocowiki\\cocowiki\\templates/base.mak'
_template_uri=u'/base.mak'
_template_cache=cache.Cache(__name__, _modified_time)
_source_encoding=None
_exports = ['title']


def render_body(context,**pageargs):
    context.caller_stack.push_frame()
    try:
        __M_locals = dict(pageargs=pageargs)
        self = context.get('self', UNDEFINED)
        _ = context.get('_', UNDEFINED)
        # SOURCE LINE 1
        context.write(u'<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"\n  "http://www.w3.org/TR/html4/loose.dtd">\n<html lang="ja">\n<head>\n<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />\n<meta http-equiv="content-style-type" content="text/css">\n<title>')
        # SOURCE LINE 7
        context.write(unicode(self.title()))
        context.write(u'</title>\n<link rel="stylesheet" type="text/css" href="/csstemplate/style.css">\n</head>\n<body id="INDEX">\n\n<div id="PAGETOP">\n\n<div id="HEADER"><h1>CoCoWiki</h1></div>\n\n<div id="MENU">\n<h2>')
        # SOURCE LINE 17
        context.write(unicode( _('menu') ))
        context.write(u'</h2>\n <ul>\n   <li id="MENU01"><a href="/StartPage">Home</a></li>\n   <li id="MENU02"><a href="/list">Index</a></li>\n  </ul>\n</div><!-- END MENU -->\n<hr>\n\n<div id="KIZI">\n<div class="text">\n')
        # SOURCE LINE 27
        context.write(unicode(self.body()))
        context.write(u'\n</div>\n</div><!-- END KIZI -->\n\n<div id="FOOTER">\n<ul>\n  <li id="FOOTER01">Powered by <a href="http://pylonshq.com/">Pylons</a></li>\n  <li id="FOOTER02">Designed by <a href="http://stans.xtr.jp/">stans</a></li>\n</ul>\n</div><!-- END FOOTER -->\n\n</div><!-- END PAGETOP -->\n</body>\n</html>\n')
        # SOURCE LINE 41
        context.write(u'\n')
        return ''
    finally:
        context.caller_stack.pop_frame()


def render_title(context):
    context.caller_stack.push_frame()
    try:
        # SOURCE LINE 41
        context.write(u'title comes here')
        return ''
    finally:
        context.caller_stack.pop_frame()


