from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
_magic_number = 2
_modified_time = 1184726431.062
_template_filename='Z:\\docs\\labs\\cocowiki\\cocowiki\\templates/list.mak'
_template_uri='/list.mak'
_template_cache=cache.Cache(__name__, _modified_time)
_source_encoding=None
_exports = ['title']


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, u'base.mak', _template_uri)
def render_body(context,**pageargs):
    context.caller_stack.push_frame()
    try:
        __M_locals = dict(pageargs=pageargs)
        self = context.get('self', UNDEFINED)
        c = context.get('c', UNDEFINED)
        _ = context.get('_', UNDEFINED)
        # SOURCE LINE 1
        context.write(u'\n')
        # SOURCE LINE 2
        context.write(u'\n\n<h2>')
        # SOURCE LINE 4
        context.write(unicode(self.title()))
        context.write(u'</h2>\n')
        # SOURCE LINE 5
        if c.words:
            # SOURCE LINE 6
            context.write(u'<ul>\n')
            # SOURCE LINE 7
            for word in c.words:
                # SOURCE LINE 8
                context.write(u'  <li><a href="')
                context.write(unicode(word.get_absolute_url()))
                context.write(u'">')
                context.write(filters.html_escape(unicode(word.word )))
                context.write(u'</a></li>\n')
            # SOURCE LINE 10
            context.write(u'</ul>\n')
            # SOURCE LINE 11
        else:
            # SOURCE LINE 12
            context.write(u'  <p>')
            context.write(unicode( _('No pages') ))
            context.write(u'</p>\n')
        return ''
    finally:
        context.caller_stack.pop_frame()


def render_title(context):
    context.caller_stack.push_frame()
    try:
        _ = context.get('_', UNDEFINED)
        # SOURCE LINE 2
        context.write(unicode( _('All pages') ))
        return ''
    finally:
        context.caller_stack.pop_frame()


