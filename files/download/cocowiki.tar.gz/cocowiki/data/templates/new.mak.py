from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
_magic_number = 2
_modified_time = 1184716055.75
_template_filename='Z:\\docs\\labs\\cocowiki\\cocowiki\\templates/new.mak'
_template_uri='/new.mak'
_template_cache=cache.Cache(__name__, _modified_time)
_source_encoding=None
_exports = ['title']


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, u'base.html', _template_uri)
def render_body(context,**pageargs):
    context.caller_stack.push_frame()
    try:
        __M_locals = dict(pageargs=pageargs)
        h = context.get('h', UNDEFINED)
        _ = context.get('_', UNDEFINED)
        # SOURCE LINE 1
        context.write(u'\n')
        # SOURCE LINE 2
        context.write(u'\n\n<h2>')
        # SOURCE LINE 4
        _('Create a New Page') 
        
        context.write(u'</h2>\n')
        # SOURCE LINE 5
        context.write(unicode(h.form('/new', method='post')))
        context.write(u'\n<p><label>')
        # SOURCE LINE 6
        context.write(unicode( _('Word') ))
        context.write(u'</label>\n')
        # SOURCE LINE 7
        context.write(unicode( h.text_field('word') ))
        context.write(u'\n</p>\n<p><label>')
        # SOURCE LINE 9
        context.write(unicode( _('Content') ))
        context.write(u'</label>\n')
        # SOURCE LINE 10
        context.write(unicode( h.text_area('content', size='30x10') ))
        context.write(u'\n</p>\n<p>\n')
        # SOURCE LINE 13
        context.write(unicode( h.submit(value=_('Create')) ))
        context.write(u'\n</p>\n')
        # SOURCE LINE 15
        context.write(unicode( h.end_form() ))
        return ''
    finally:
        context.caller_stack.pop_frame()


def render_title(context):
    context.caller_stack.push_frame()
    try:
        _ = context.get('_', UNDEFINED)
        # SOURCE LINE 2
        context.write(unicode(_('Creating a New Page')))
        return ''
    finally:
        context.caller_stack.pop_frame()


