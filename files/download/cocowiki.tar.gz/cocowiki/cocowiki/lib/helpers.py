# -*- coding: utf-8 -*-
"""Helper functions

Consists of functions to typically be used within templates, but also available
to Controllers. This module is available to both as 'h'.
"""
from webhelpers import *
from urllib import quote
import re
from cgi import escape

WIKI_WORD_RE = re.compile(r'\[\[(.+?)\]\]')

def cocowiki_markup(value):
    """
    WIKIのページデータをHTMLに変換します。
    """
    def repl(matcher):
        word = matcher.group(1)
        return '<a href="%s">%s</a>' % (quote(word.encode('utf-8')),
                                        escape(word))

    # markdown記法で変換
    value = markdown(value)

    # http://example.com, mail@example.comをリンクに変換
    value = auto_link(value)

    # [[word]]という表記をWikiワードとして扱う
    value = WIKI_WORD_RE.sub(repl, value)

    return value
