# -*- coding: utf-8 -*-
from sqlalchemy import *
from sqlalchemy.ext.assignmapper import assign_mapper

from urllib import quote
from datetime import datetime

from sacontext import PylonsSAContext

# Pylons 0.9.6から以前のpylons.databasesがdeprecated扱いになりました。
# 代わりにSAContextのPylonsSAContextを使うことが推奨されています。
# 詳しくはhttp://sluggo.scrapping.cc/python/sacontext/を参照してください。
sac = PylonsSAContext()
sac.add_engine_from_config(None)

# テーブル定義
pages = Table('pages', sac.metadata,
              Column('id', Integer, primary_key=True),
              Column('word', Unicode(250), nullable=False, unique=True),
              Column('content', Unicode, nullable=False),
              Column('created_at', DateTime, default=datetime.now()),
              Column('updated_at', DateTime, default=datetime.now(), onupdate=datetime.now()),
              mysql_engine='InnoDB',
              )

# Wikiのページに相当するドメインオブジェクト
class Page(object):
    def __init__(self, word=None, content=None):
        self.word = word
        self.content = content

    def __repr__(self):
        return '<cocowiki.model.Page "%s">' % self.word

    def get_absolute_url(self):
        """
        このオブジェクトのURLを取得します
        これはPylonsの流儀ではないかもしれませんが便利です！
        """
        return '/%s' % quote(self.word.encode('utf-8'))

# AssignMapperを使ってテーブルとドメインオブジェクトを
# マッピングします
assign_mapper(sac.session_context,
              Page,
              pages)
