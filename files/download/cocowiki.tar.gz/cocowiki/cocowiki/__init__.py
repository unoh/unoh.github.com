"""cocowiki

This file loads the finished app from cocowiki.config.middleware.
"""
from cocowiki.config.middleware import make_app
