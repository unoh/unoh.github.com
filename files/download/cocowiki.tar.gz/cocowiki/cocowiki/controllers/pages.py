# -*- coding: utf-8 -*-
import logging
from urllib import quote
from sqlalchemy import desc

from cocowiki.lib.base import *
from cocowiki.model import Page

log = logging.getLogger(__name__)

from formencode import validators
from formencode.schema import Schema

class PageSchema(Schema):
    allow_extra_fields = True
    content = validators.String(not_empty=True)

class PagesController(BaseController):
    def __before__(self):
        # 各リクエストの開始前にSQLAlchemyのセッションを初期化します
        # @TODO
        # 以前のバージョンのPylonsでは必須でしたが、今はどうだろう・・・
        model.sac.session_context.current.clear()

    def index(self, format='html'):
        """
        登録済みのWikiワードを取得します
        """
        c.words = Page.select(order_by=Page.c.word)
        return render('list')

    @validate(schema=PageSchema(), form='edit')
    def update(self, word):
        """
        Wikiワード"word"を更新します。
        wordが未登録の場合は新規登録します。
        """
        page = Page.get_by(word=word)
        if page is None:
            page = Page(word=word)

        page.content = self.form_result['content']
        page.flush()

        # 更新、新規登録したページにリダイレクト
        redirect_to(page.get_absolute_url())

    def show(self, word=None, format='html'):
        """
        Wikiワード"Word"を表示します。
        WordがNoneの場合、つまりURLが"/"の場合は、/StartPage
        にリダイレクトさせます。
        """
        if not word:
            redirect_to('/StartPage')

        c.page = Page.get_by(word=word)
        if c.page is None:
            # wordでページが登録されていない場合は、
            # 新規登録のフォームを表示します。
            return self.edit(word)

        # 更新順に10件のページを取得します。
        # limit=11で最大11件表示しているのは、「もっと見る」の
        # リンクの表示する条件を簡略化するためです。
        c.words = Page.select(order_by=desc(Page.c.updated_at),
                              limit=11)
        return render('show')

    def edit(self, word, format='html'):
        """
        Wiki更新、新規登録のフォームを表示します。
        """
        c.word = word
        page = Page.get_by(word=word)
        c.form_result = {'content': page and page.content or ''}
        return render('edit')
