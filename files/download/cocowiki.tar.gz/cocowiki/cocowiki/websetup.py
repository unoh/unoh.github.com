# -*- coding: utf-8 -*-
"""Setup the cocowiki application"""
from paste.deploy import appconfig
from pylons import config

from cocowiki.config.environment import load_environment

def setup_config(command, filename, section, vars):
    """Place any commands to setup cocowiki here"""
    conf = appconfig('config:' + filename)
    load_environment(conf.global_conf, conf.local_conf)

    from sqlalchemy import exceptions
    from cocowiki.model import sac, Page
    sac.metadata.create_all(checkfirst=True)

    try:
        start_page = Page('StartPage', u'ここうぃきの世界にようこそ')
        sac.session_context.current.flush()
    except exceptions.SQLError, e:
        pass
