# -*- coding: utf-8 -*-
"""Routes configuration

The more specific and detailed routes should be defined first so they may take
precedent over the more generic routes. For more information refer to the
routes manual at http://routes.groovie.org/docs/
"""
from pylons import config
from routes import Mapper

def make_map():
    """Create, configure and return the routes Mapper"""
    map = Mapper(directory=config['pylons.paths']['controllers'],
                 always_scan=config['debug'])

    # The ErrorController route (handles 404/500 error pages); it should likely
    # stay at the top, ensuring it can always be resolved
    map.connect('error/:action/:id', controller='error')

    # CUSTOM ROUTES HERE

    # 今回はPylonsのデフォルトの設定を使わないので
    # コメントアウトしています。
    #map.connect(':controller/:action/:id')
    #map.connect('*url', controller='template', action='view')

    # 登録されている単語を表示するページです。
    map.connect('list', controller='pages', action='index')

    # Wikiの編集フォームのページ
    map.connect('*(word);edit', controller='pages', action='edit')

    # Wiki更新のアクションのマッピングです。
    # フォームの内容にエラーがある場合は、再度上のeditページを表示します。
    map.connect('*word', controller='pages', action='update', conditions={'method':['POST']})

    # Wikiの個々のページです。
    # 上記のform, edit, list以外の単語がWikiワードになります。
    map.connect('*word', controller='pages', action='show')

    return map
