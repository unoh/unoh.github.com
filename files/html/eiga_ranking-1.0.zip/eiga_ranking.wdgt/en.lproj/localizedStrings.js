var localizedStrings = new Object;

localizedStrings["My RSS Feed"] = unescape('%u6620%u753B%u751F%u6D3B%u30E9%u30F3%u30AD%u30F3%u30B0');
localizedStrings["New URL: "] = "New URL: ";
localizedStrings["Set"] = "Set";
localizedStrings["Feed URLs: "] = "Feed URLs: ";
localizedStrings["Article Length"] = "Article Length";
localizedStrings["Reset"] = "Reset";
localizedStrings["Done"] = "Done";
localizedStrings["Invalid Feed"] = "Invalid Feed";
localizedStrings["%s does not appear to be a valid RSS or Atom feed."] = "%s does not appear to be a valid RSS or Atom feed.";
localizedStrings["No Items Found"] = "No Items Found";
localizedStrings["The feed does not contain any entries."] = "The feed does not contain any entries.";
localizedStrings["No items matched the search terms."] = "No items matched the search terms.";
localizedStrings["Nothing To Display"] = "Nothing To Display";
localizedStrings["The feed does not contain any entries within the specified criteria."] = "The feed does not contain any entries within the specified criteria.";
localizedStrings["Loading"] = "Loading";
localizedStrings["%s new"] = "%s new";
